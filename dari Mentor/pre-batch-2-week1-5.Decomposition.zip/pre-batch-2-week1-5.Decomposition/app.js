document.getElementById("testing").innerHTML = "INI DARI JAVASCRIPT";
